(function ($, app) {
    "use strict";
    $(document).ready(function () {
    });
})(window.jQuery, window.app);