<?php

namespace Payroll\Repository;

use Exception;
use SelfService\Model\AdvanceRequest;

class VoucherGenerationRepo {

    public function generateAdvanceVoucher(AdvanceRequest $advance) {
        try {
            $companyCode="";
            $formCode="";
            $transactionDate="";
            $tableName="";
            
            
            
            
            
            
            
            
        } catch (Exception $e) {
            
        }
    }

}
